import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

class Account implements Comparable<Account> {
    final String number;
    final String owner;
    double balance;

    Account(String number, String owner, double balance) {
        this.number = number;
        this.owner = owner;
        this.balance = balance;
    }

    @Override
    public int compareTo(Account other) {
        return this.number.compareTo(other.number); // Natural order by account number
    }

    @Override
    public String toString() {
        return String.format("[%s | %s | $%.2f]", number, owner, balance);
    }
}

class AccountStore {
    private final Map<String, Account> accounts = new HashMap<>();
    private final List<String> history = new ArrayList<>();

    void add(Account account) {
        accounts.put(account.number, account);
    }

    Account get(String number) {
        return accounts.get(number);
    }

    List<Account> getAll() {
        return new ArrayList<>(accounts.values());
    }

    List<Account> sortedByBalance() {
        return accounts.values().stream()
                .sorted(Comparator.comparingDouble(a -> a.balance))
                .toList();
    }

    void record(String transaction) {
        history.add(transaction);
    }

    List<String> history() {
        return List.copyOf(history);
    }
}

public class MiniBank {
    private static String prompt(Scanner scanner, String message, String defaultValue) {
        System.out.print(message + " (default '" + defaultValue + "'): ");
        if (scanner.hasNextLine()) {
            String line = scanner.nextLine().trim();
            return line.isEmpty() ? defaultValue : line;
        }
        System.out.println(defaultValue);
        return defaultValue;
    }

    public static void main(String[] args) {
        System.out.println("=== Practical 12: Java Collections Framework & Stream Sorting ===");

        AccountStore store = new AccountStore();
        store.add(new Account("MB1201", "Asha", 900.0));
        store.add(new Account("MB1202", "Ravi", 1200.0));

        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("\n--- Add a New Account to Store ---");
            String accNum = prompt(scanner, "Enter Account Number", "MB1203");
            String owner = prompt(scanner, "Enter Account Owner", "Kavita");
            double balance = Double.parseDouble(prompt(scanner, "Enter Opening Balance", "1500.0"));

            store.add(new Account(accNum, owner, balance));

            String tx = prompt(scanner, "Enter a transaction note for history log", accNum + " OPEN_ACCOUNT");
            store.record(tx);

            
            System.out.println("\n--- Sorted by Account Number (Comparable / TreeSet) ---");
            TreeSet<Account> byAccNumber = new TreeSet<>(store.getAll());
            for (Account acc : byAccNumber) {
                System.out.println("  " + acc);
            }

            
            System.out.println("\n--- Sorted by Balance Ascending (Comparator) ---");
            List<Account> byBalance = store.sortedByBalance();
            for (Account acc : byBalance) {
                System.out.println("  " + acc);
            }

            
            ConcurrentHashMap<String, Account> sharedMap = new ConcurrentHashMap<>();
            store.getAll().forEach(acc -> sharedMap.put(acc.number, acc));

            System.out.println("\n--- Transaction History Log ---");
            System.out.println("History records: " + store.history());
            System.out.println("ConcurrentHashMap item count: " + sharedMap.size());
        }
    }
}
