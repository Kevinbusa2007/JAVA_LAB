import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Account {
    private double balance;
    private final Object lock = new Object();

    Account(double initialBalance) {
        this.balance = initialBalance;
    }

    void deposit(double amount) {
        synchronized (lock) {
            balance += amount;
        }
    }

    void withdraw(double amount) {
        synchronized (lock) {
            if (balance >= amount) {
                balance -= amount;
            }
        }
    }

    double balance() {
        synchronized (lock) {
            return balance;
        }
    }
}

class AccountWorker implements Runnable {
    private final Account account;
    private final int operations;

    AccountWorker(Account account, int operations) {
        this.account = account;
        this.operations = operations;
    }

    @Override
    public void run() {
        System.out.println("  " + Thread.currentThread().getName() + " started.");
        for (int i = 0; i < operations; i++) {
            account.deposit(1.0);
            account.withdraw(1.0);
        }
        System.out.println("  " + Thread.currentThread().getName() + " finished.");
    }
}

public class MiniBank {
    private static String prompt(Scanner scanner, String message, String defaultValue) {
        System.out.print(message + " (default '" + defaultValue + "'): ");
        if (scanner.hasNextLine()) {
            String line = scanner.nextLine().trim();
            return line.isEmpty() ? defaultValue : line;
        }
        System.out.println(defaultValue);
        return defaultValue;
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Practical 09: Multithreading, Concurrency & Synchronization ===");

        try (Scanner scanner = new Scanner(System.in)) {
            double initialBalance = Double.parseDouble(prompt(scanner, "Enter initial account balance", "1000.0"));
            int threadCount = Integer.parseInt(prompt(scanner, "Enter number of concurrent threads (1-20)", "5"));
            int opsPerThread = Integer.parseInt(prompt(scanner, "Enter iterations per thread", "500"));

            threadCount = Math.clamp(threadCount, 1, 20);
            opsPerThread = Math.max(1, opsPerThread);

            Account account = new Account(initialBalance);
            System.out.printf("%nStarting simulation: %d threads, each performing %d deposit-and-withdraw operations.%n",
                    threadCount, opsPerThread);
            System.out.println("Initial Balance: $" + account.balance());

            List<Thread> workers = new ArrayList<>();
            for (int i = 0; i < threadCount; i++) {
                Thread worker = new Thread(new AccountWorker(account, opsPerThread), "Worker-" + (i + 1));
                workers.add(worker);
                worker.start();
            }

            for (Thread worker : workers) {
                worker.join();
            }

            System.out.println("\nAll worker threads completed.");
            System.out.println("Final Account Balance: $" + account.balance());
            if (account.balance() == initialBalance) {
                System.out.println("SUCCESS: Balance is consistent! Synchronization maintained thread safety.");
            } else {
                System.out.println("Race condition detected! Final balance deviates from expected.");
            }
        }
    }
}
